image_pipeline
==============

.. image:: https://travis-ci.org/ros-perception/image_pipeline.svg?branch=indigo
    :target: https://travis-ci.org/ros-perception/image_pipeline

This package fills the gap between getting raw images from a camera driver and higher-level vision processing.
