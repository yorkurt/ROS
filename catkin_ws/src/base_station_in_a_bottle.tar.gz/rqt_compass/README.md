# rqt_compass
A UI widget for directional navigation via arduino-based magnometer and GPS
