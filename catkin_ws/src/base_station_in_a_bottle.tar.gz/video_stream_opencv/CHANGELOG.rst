^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package video_stream_opencv
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.2 (2016-11-14)
------------------

1.0.1 (2016-11-14)
------------------
* Releasable version
* Contributors: Sammy Pfeiffer, Stefano Probst, Wiebe Van Ranst
